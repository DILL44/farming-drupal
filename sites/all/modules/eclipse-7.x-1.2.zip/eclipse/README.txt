INSTALL
-------

In Eclipse PDT 2.2, the import menu for the Drupal template XML is at:

Eclipse global preferences -> PHP -> Editor -> Templates

Eclipse derivatives like Zend Studio probably have it elsewhere.